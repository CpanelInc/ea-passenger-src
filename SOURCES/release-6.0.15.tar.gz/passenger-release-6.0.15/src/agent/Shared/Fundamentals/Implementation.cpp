#ifndef _GNU_SOURCE
	#define _GNU_SOURCE
#endif

#include <Shared/Fundamentals/Initialization.cpp>
#include <Shared/Fundamentals/AbortHandler.cpp>
#include <Shared/Fundamentals/Utils.cpp>
