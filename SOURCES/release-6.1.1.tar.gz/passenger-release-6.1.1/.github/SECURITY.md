# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| latest | :white_check_mark: |
| last 5 years' releases | with sufficient support subscription |

## Reporting a Vulnerability

You can email security@phusionpassenger.com to report security issues. We do not offer bug bounties.
